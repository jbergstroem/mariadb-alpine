create database mydatabasegz;
